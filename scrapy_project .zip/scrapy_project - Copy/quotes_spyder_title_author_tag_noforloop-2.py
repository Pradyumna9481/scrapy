# -*- coding: utf-8 -*-

import scrapy

class QuoteSpider(scrapy.Spider):
    name = 'quotes'
    start_urls = [
            'http://quotes.toscrape.com/'
            ]
    
    def parse(self, response):
        # 1. quotes 2. Author 3. tag
        
        all_div_quotes = response.css('div.quote')
        title = all_div_quotes.css('span.text::text').extract()
        author = all_div_quotes.css('.author::text').extract()
        tag = all_div_quotes.css('.tag::text').extract()
        
        yield{
                'Title' : title,
                'Author' : author,
                'Tag' : tag,
                }